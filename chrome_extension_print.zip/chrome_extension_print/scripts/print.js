document.getElementById("printbutton").addEventListener("click", myFunction);

function myFunction(){
  window.print();
}