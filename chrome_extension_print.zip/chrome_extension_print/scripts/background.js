"use strict";
chrome.runtime.onInstalled.addListener(function (o) {
    console.log("previousVersion", o.previousVersion)
}), console.log("'Allo 'Allo! Event Page");
//# sourceMappingURL=background.js.map